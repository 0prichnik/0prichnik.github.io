import './shared/device-polyfill'

App({
  globalData: {},
  onCreate(options) {},
  onDestroy(options) {}
})
